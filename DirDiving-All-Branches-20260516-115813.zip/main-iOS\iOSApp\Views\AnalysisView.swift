import SwiftUI
import Charts

struct AnalysisView: View {
    @EnvironmentObject private var logStore: DiveLogStore

    var body: some View {
        NavigationStack {
            ZStack {
                DIRBackground()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 16) {
                        header
                        analysisHero
                        DIRCard("ANALISI AVANZATE", icon: "chart.line.uptrend.xyaxis", accent: DIRTheme.cyan) {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 0) {
                                DIRMetricTile(title: "Immersioni", value: "\(logStore.sessions.count)", color: DIRTheme.cyan)
                                DIRMetricTile(title: "Max assoluta", value: Formatters.one(logStore.sessions.map(\.maxDepthMeters).max() ?? 0), unit: "m", color: DIRTheme.yellow)
                                DIRMetricTile(title: "Runtime totale", value: Formatters.zero(logStore.sessions.map(\.durationSeconds).reduce(0, +) / 60), unit: "min")
                                DIRMetricTile(title: "Temp media", value: Formatters.one(avgTemp), unit: "C")
                            }
                        }
                        DIRCard("PROFONDITA MASSIMA PER IMMERSIONE", icon: "chart.xyaxis.line", accent: DIRTheme.cyan) {
                            Chart(logStore.sessions) { session in
                                BarMark(
                                    x: .value("Data", session.startDate, unit: .day),
                                    y: .value("Max", session.maxDepthMeters)
                                )
                                .foregroundStyle(
                                    LinearGradient(colors: [DIRTheme.cyan, DIRTheme.green], startPoint: .top, endPoint: .bottom)
                                )
                            }
                            .chartXAxis { AxisMarks { AxisGridLine().foregroundStyle(DIRTheme.faint); AxisValueLabel().foregroundStyle(DIRTheme.muted) } }
                            .chartYAxis { AxisMarks { AxisGridLine().foregroundStyle(DIRTheme.faint); AxisValueLabel().foregroundStyle(DIRTheme.muted) } }
                            .chartPlotStyle { plot in
                                plot
                                    .background(
                                        LinearGradient(
                                            colors: [.black.opacity(0.32), DIRTheme.surface.opacity(0.32)],
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )
                                    .clipShape(RoundedRectangle(cornerRadius: DIRTheme.compactRadius))
                                    .overlay(RoundedRectangle(cornerRadius: DIRTheme.compactRadius).stroke(DIRTheme.hairline, lineWidth: 1))
                            }
                            .frame(height: 240)
                        }
                        apneaPresentation
                        snorkelingSummary
                    }
                    .padding(16)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var analysisHero: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Operational Overview")
                    .font(.headline.weight(.semibold))
                    .foregroundStyle(.white)
                Text("Logbook trends, apnea readiness presentation and snorkeling summaries")
                    .font(.footnote)
                    .foregroundStyle(DIRTheme.muted)
            }
            Spacer()
            Image(systemName: "waveform.path.ecg.rectangle")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(DIRTheme.cyan)
                .frame(width: 54, height: 54)
                .background(RoundedRectangle(cornerRadius: 16).fill(DIRTheme.cyan.opacity(0.12)))
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: DIRTheme.cardRadius)
                .fill(LinearGradient(colors: [DIRTheme.cyan.opacity(0.14), DIRTheme.surface.opacity(0.86)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: DIRTheme.cardRadius).stroke(DIRTheme.cyan.opacity(0.36), lineWidth: 1))
        )
    }

    private var avgTemp: Double {
        let values = logStore.sessions.compactMap(\.avgWaterTemperatureCelsius)
        return values.isEmpty ? 0 : values.reduce(0, +) / Double(values.count)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("Analisi")
                .font(.system(size: 30, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("Clean operational metrics, trends and visual-only experimental summaries")
                .font(.callout)
                .foregroundStyle(DIRTheme.muted)
        }
    }

    private var apneaPresentation: some View {
        DIRCard("APNEA READINESS", icon: "lungs.fill", accent: DIRTheme.yellow) {
            // TODO: Static presentation only; connect readiness, recovery and fatigue analytics after product approval.
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    analysisPill("Readiness", "--%", DIRTheme.yellow, "heart.fill")
                    analysisPill("Recovery", "2.4x", DIRTheme.green, "timer")
                    analysisPill("Fatigue", "N/A", DIRTheme.red, "waveform.path.ecg")
                }
                HStack(spacing: 12) {
                    trendCard("Depth trend", "stable", DIRTheme.cyan)
                    trendCard("Surface interval", "visual", DIRTheme.green)
                }
                apneaDepthPreview
            }
        }
    }

    private var apneaDepthPreview: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("DEPTH CURVE PREVIEW")
                .font(.caption2.weight(.bold))
                .foregroundStyle(DIRTheme.cyan)
            AnalysisDepthTrendPreview()
                .frame(height: 96)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: DIRTheme.compactRadius).fill(.black.opacity(0.18)))
    }

    private var snorkelingSummary: some View {
        DIRCard("SNORKELING SESSION SUMMARY", icon: "figure.pool.swim", accent: DIRTheme.green) {
            // TODO: Placeholder presentation only; do not implement route analytics here.
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    DIRMetricTile(title: "Routes", value: "--", color: DIRTheme.cyan)
                    Divider().overlay(DIRTheme.hairline)
                    DIRMetricTile(title: "Entry/Exit", value: "UI", color: DIRTheme.green)
                    Divider().overlay(DIRTheme.hairline)
                    DIRMetricTile(title: "Waypoints", value: "--", color: DIRTheme.yellow)
                }
                Divider().overlay(DIRTheme.hairline)
                Text("Route overview, waypoint lists and entry/exit hierarchy are presented in Explore as UI-only concepts.")
                    .font(.footnote)
                    .foregroundStyle(DIRTheme.muted)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 12)
            }
        }
    }

    private func analysisPill(_ title: String, _ value: String, _ color: Color, _ icon: String) -> some View {
        VStack(spacing: 7) {
            Image(systemName: icon)
                .foregroundStyle(color)
            Text(value)
                .font(.title3.monospacedDigit().weight(.bold))
                .foregroundStyle(.white)
            Text(title)
                .font(.caption2.weight(.semibold))
                .foregroundStyle(DIRTheme.muted)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(RoundedRectangle(cornerRadius: 8).fill(DIRTheme.surface2.opacity(0.6)))
    }

    private func trendCard(_ title: String, _ value: String, _ color: Color) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(DIRTheme.muted)
                Text(value.uppercased())
                    .font(.callout.weight(.bold))
                    .foregroundStyle(.white)
            }
            Spacer()
            Circle()
                .fill(color)
                .frame(width: 10, height: 10)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 8).fill(DIRTheme.surface2.opacity(0.6)))
    }
}

private struct AnalysisDepthTrendPreview: View {
    var body: some View {
        Canvas { context, size in
            let gridColor = Color.white.opacity(0.08)
            for y in stride(from: 0.0, through: size.height, by: 24) {
                var grid = Path()
                grid.move(to: CGPoint(x: 0, y: y))
                grid.addLine(to: CGPoint(x: size.width, y: y))
                context.stroke(grid, with: .color(gridColor), lineWidth: 1)
            }

            var path = Path()
            path.move(to: CGPoint(x: 0, y: size.height * 0.18))
            path.addCurve(to: CGPoint(x: size.width * 0.26, y: size.height * 0.82), control1: CGPoint(x: 30, y: 18), control2: CGPoint(x: 48, y: size.height * 0.82))
            path.addLine(to: CGPoint(x: size.width * 0.52, y: size.height * 0.76))
            path.addCurve(to: CGPoint(x: size.width, y: size.height * 0.2), control1: CGPoint(x: size.width * 0.68, y: size.height * 0.7), control2: CGPoint(x: size.width * 0.78, y: size.height * 0.24))
            context.stroke(path, with: .color(DIRTheme.cyan), style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
        }
        .background(RoundedRectangle(cornerRadius: DIRTheme.compactRadius).fill(.black.opacity(0.22)))
    }
}
